from cif_py.cli import *
"""
This is a package for parsing cif files.
"""
